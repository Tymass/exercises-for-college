# pliers detctor > 2023-05-18 4:26pm
https://universe.roboflow.com/tymek-byrwa-1p3fh/pliers-detctor

Provided by a Roboflow user
License: MIT

